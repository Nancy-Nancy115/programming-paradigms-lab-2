                                           //1.RECORDS
type Coach = { 
    Name: string
    FormerPlayer: bool
}

type Stats = { 
    Wins: int
    Losses: int 
}

type Team = { 
    Name: string
    Coach: Coach
    Stats: Stats
}


let teamList = [
    { Name = "Atlanta Hawks"; Coach = { Name = "Quin Snyder"; FormerPlayer = false }; Stats = { Wins = 7; Losses = 11 } }
    { Name = "Boston Celtics"; Coach = { Name = "Joe Mazzulla"; FormerPlayer = false }; Stats = { Wins = 15; Losses = 3 } }
    { Name = "Brooklyn Nets"; Coach = { Name = "Jordi Fernandez"; FormerPlayer = false }; Stats = { Wins = 8; Losses = 10 } }
    { Name = "Charlotte Hornets"; Coach = { Name = "Charles Lee"; FormerPlayer = false }; Stats = { Wins = 6; Losses = 11 } }
    { Name = "Chicago Bulls"; Coach = { Name = "Billy Donovan"; FormerPlayer = false }; Stats = { Wins = 8; Losses = 11 } }
]


let successfulTeams =
    teamList
    |> List.filter (fun team -> team.Stats.Wins > team.Stats.Losses)


let successPercentages =
    teamList
    |> List.map (fun team -> 
        let percentage = (float team.Stats.Wins / float (team.Stats.Wins + team.Stats.Losses)) * 100.0
        team.Name, percentage
    )


printfn "Successful Teams: %A" (successfulTeams |> List.map (fun team -> team.Name))
printfn "Success Percentages: %A" successPercentages
          


         

                                  //2.DISCRIMINATED UNION
type Cuisine =
    | Korean
    | Turkish


type MovieType =
    | Regular
    | IMAX
    | DBOX
    | RegularWithSnacks
    | IMAXWithSnacks
    | DBOXWithSnacks


type Activity =
    | BoardGame
    | Chill
    | Movie of MovieType
    | Restaurant of Cuisine
    | LongDrive of int * float 


let calculateBudget activity =
    match activity with
    | BoardGame -> 0
    | Chill -> 0
    | Movie movieType ->
        match movieType with
        | Regular -> 12
        | IMAX -> 17
        | DBOX -> 20
        | RegularWithSnacks -> 12 + 5
        | IMAXWithSnacks -> 17 + 5
        | DBOXWithSnacks -> 20 + 5
    | Restaurant cuisine ->
        match cuisine with
        | Korean -> 70
        | Turkish -> 65
    | LongDrive (kilometers, fuelCostPerKm) -> int (float kilometers * fuelCostPerKm)


[<EntryPoint>]
let main argv =
    let activity1 = BoardGame
    let activity2 = Chill
    let activity3 = Movie IMAXWithSnacks
    let activity4 = Restaurant Korean
    let activity5 = LongDrive (100, 1.25)

    printfn "Board Game: %d CAD" (calculateBudget activity1)
    printfn "Chilling out: %d CAD" (calculateBudget activity2)
    printfn "Movie (IMAX with Snacks): %d CAD" (calculateBudget activity3)
    printfn "Restaurant (Korean): %d CAD" (calculateBudget activity4)
    printfn "Long Drive (100 km, 1.25 CAD/km): %d CAD" (calculateBudget activity5)

    0 
